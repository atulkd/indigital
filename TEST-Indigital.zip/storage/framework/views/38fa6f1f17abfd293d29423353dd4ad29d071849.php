<?php $__env->startSection('content'); ?>



<h2>Company User List</h2>

<?php if(session('create_user')): ?>
                        <div class="alert alert-success">
                             <?php echo e(session('create_user')); ?> 
                        </div>
<?php endif; ?> 

<div class="btn-group" style="padding-left: 10px;align:right;" >
    <a href="<?php echo e('create-new-company-user'); ?>" class="btn btn-primary"> Add New User<i class="fa fa-plus"></i> </a>
</div>

<table>
  <thead>
    <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Mobile</th>
    <th>Company Name</th>
    <th>Designation</th>
    <th>Company Size</th>
    
  </tr>
  </thead>
  <tbody>
 <?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  <tr>
    <td><?php echo e($key->name); ?></td>
    <td><?php echo e($key->email); ?></td>
    <td><?php echo e($key->usr_mobile); ?></td>
    <td><?php echo e($key->usr_cmp_name); ?></td>
    <td><?php echo e($key->usr_designation); ?></td>
    <td><?php echo e($key->usr_cmp_size); ?></td>
   
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
  
 
 
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>