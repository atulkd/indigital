<?php $__env->startSection('content'); ?>




<div class="container_1">
  <h2>Company User Registration Form</h2>
  <div class="row">
  <form id="company-user-registration-form">
    <div class="col-lg-12">
      <div class="alert alert-danger print-error-msg" style="display:none">
        <ul> </ul>
    </div>
    </div>


    <div class="col-lg-12">
        <div class="col-lg-6">
            <div class="form-group">
              <label for="cmp_usr_name">Username *:</label>
              <input type="text" id="cmp_usr_name" name="cmp_usr_name" class="form-control" placeholder="Enter Username"/>
              <span class="error-message"></span>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
              <label for="cmp_usr_email">Email *:</label>
              <input type="email" class="form-control" id="cmp_usr_email" placeholder="Enter email" name="cmp_usr_email">
              <span class="error-message"></span>
            </div>
        </div>
    </div>

    <div class="col-lg-12">
        <div class="col-lg-6">
            <div class="form-group">
              <label for="cmp_usr_mobile">Mobile *:</label>
              <input type="text" class="form-control" id="cmp_usr_mobile" name="cmp_usr_mobile" placeholder="Enter Mobile">
              <span class="error-message"></span>
            </div>
        </div>

        <div class="col-lg-6">
             <div class="form-group">
              <label for="cmp_usr_password">Password *:</label><span id="result"></span>
              <input type="password" class="form-control" id="cmp_usr_password" placeholder="Enter password" name="cmp_usr_password">
              <span class="error-message"></span>
            </div>
        </div>
    </div>

    <div class="col-lg-12">

        <div class="col-lg-6">
            <div class="form-group">
              <label for="retype_password">Retype Password *:</label>
              <input type="password" class="form-control" id="retype_password" placeholder="Re-Enter password" name="retype_password">
              <span class="error-message"></span>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="form-group">
              <label for="cmp_name">Company Name *:</label>
              <input type="text" class="form-control" id="cmp_name" name="cmp_name" placeholder="Enter Company Name">
              <span class="error-message"></span>
            </div>
        </div>

    </div>

    <div class="col-lg-12">

        <div class="col-lg-6">
            <div class="form-group">
              <label for="cmp_usr_designation">Designation *:</label>
              <input type="text" class="form-control" id="cmp_usr_designation" name="cmp_usr_designation" placeholder="Enter Designation">
              <span class="error-message"></span>
            </div>
        </div>

        <div class="col-lg-6">

            <div class="form-group">
              <label for="cmp_size">Company Size *:</label> 

              <input type="text" class="form-control" id="cmp_size" name="cmp_size" placeholder="Enter Comapny Size">
            <!--  <select id="cmp_size" name="cmp_size" class="form-control">
              <?php $__currentLoopData = App\User::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value='<?php echo e($city->id); ?>' ><?php echo e($city->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </select> -->
             <!-- https://laravel.com/docs/5.5/queries#joins -->
             <!-- https://stackoverflow.com/questions/41101152/foreach-laravel-5-option-select -->
              <span class="error-message"></span>
            </div>
        </div>

    </div>


     <div class="col-lg-12">

        <div class="col-lg-6">
            <div class="g-recaptcha" data-sitekey="6LcH4UsUAAAAACvu9seCQMCZnVJl8lBWeEnN2vp3" ></div>
        </div>


    </div>



    <div class="col-lg-12">
        <button type="submit" id="#form_submit" class="btn btn-default col-lg-offset-5" style="align:center;">Submit</button>
        <button type="button" class="btn btn-default " style="align:center;" onclick="history.go(-1)">Cancel</button>
    </div>
  <?php echo e(csrf_field()); ?>

    
  </form>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>