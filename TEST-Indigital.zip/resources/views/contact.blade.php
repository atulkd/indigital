@extends('layouts.app')
@section('content')



<h2>Company User List</h2>

@if (session('create_user'))
                        <div class="alert alert-success">
                             {{ session('create_user') }} 
                        </div>
@endif 

<div class="btn-group" style="padding-left: 10px;align:right;" >
    <a href="{{'create-new-company-user'}}" class="btn btn-primary"> Add New User<i class="fa fa-plus"></i> </a>
</div>

<table>
  <thead>
    <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Mobile</th>
    <th>Company Name</th>
    <th>Designation</th>
    <th>Company Size</th>
    
  </tr>
  </thead>
  <tbody>
 @foreach($user_data as $key) 
  <tr>
    <td>{{$key->name}}</td>
    <td>{{$key->email}}</td>
    <td>{{$key->usr_mobile}}</td>
    <td>{{$key->usr_cmp_name}}</td>
    <td>{{$key->usr_designation}}</td>
    <td>{{$key->usr_cmp_size}}</td>
   
  </tr>
  @endforeach

  </tbody>
  
 
 
</table>



@endsection