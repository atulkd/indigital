@extends('layouts.app')
@section('content')


<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome To Test-Indigital</div>


                 <div class="col-lg-4 col-sm-6">
                   <a href="{{url('contact')}}">
                      <section class="panel">
                          <div class="symbol red" style="    padding: 25px 10px;    background: #024764;">
                              <i class="fa fa-users" style="font-size: 50px;"></i>
                              <h1 class=" count2">
                                 <?php
                                   $check_user=DB::table('users');
                                   echo $check_user->count();
                                 ?>
                              </h1>
                          </div>
                          <div class="value" style="    padding-top: 20px;">
                              
                              <p>No of Users</p>
                          </div>
                      </section>
                      </a>
                  </div>


                
            </div>
        </div>
    </div>
</div>




@endsection





