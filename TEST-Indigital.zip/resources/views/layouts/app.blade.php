
<!DOCTYPE html>
<html>

<head>
<title>Test-Indigital</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" >
<meta name="csrf-token" content="{{ csrf_token() }}">


<style>
.navbar-collapse {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

.l_new {
    float: left;
}

.d_new {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.d_new:hover {
    background-color: #111;
}


            .container_1 {width:700px; margin:0 auto; }

            form .line.submit {text-align:right;}
table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 10px;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}

</style>


</head>

<body>




 <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav"> 
                       <li class="l_new"><a href="{{url('/')}}" class="active d_new" >Home</a></li>
                        <li class="l_new"><a href="{{url('contact')}}" class="d_new">Company Users</a></li>
                        <li class="l_new"><a href="{{url('contact-list')}}" class="d_new">Contact-List</a></li>
                    </ul>

                  
                </div>


@yield('content')
<!-- Content will go here -->

</body>
  <script type="text/javascript" src="{{ url('js/jquery.min.js')}}"></script>
  <script type="text/javascript" src="{{ url('js/jquery.validate.min.js')}}"></script>
   <script src="{{url('js/company-registration-form.js')}}" type="text/javascript"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</html>

