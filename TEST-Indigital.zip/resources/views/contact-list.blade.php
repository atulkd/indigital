@extends('layouts.app')
@section('content')


<style>
body{
  background:#f1f1f1;
  margin:0;
  font-family:sans-serif;
}

li{
  list-style:none;
}

a,
a:hover,
a:active{
  text-decoration:none;
}

h2{
  margin:0;
}

ul{
  padding:0;
  margin:0;
}

.header,
.sidebar,
.contact-list{
  background:#fff;
/*   margin:10px; */
}

.header{
  padding:20px 20px;
  margin-bottom:10px;
 }

.header h2{
  display:inline-block;
}

.header a{
  float:right;
  line-height:1;
  padding:8px;
  border:1px solid #eee;  
}

.sidebar,
.contact-list{
  display:inline-block;
  vertical-align:top;
}
.sidebar{
  width:20%;
}

.contact-list{
  width: 79%;
    float: right;
}

.avatar{
  width:60px;
  border-radius:50%;
  display:inline-block;  
  vertical-align:middle;
  margin-right:15px;
 }

.sidebar li{
  padding:10px 0;
  padding-left:10px;
  border-top:1px solid #eee  
}

.contact-list li{
  border-top:1px solid #eee;
  padding:25px 20px;
}

.contact-list li > p{
    display:inline-block;
    margin:0;
    vertical-align:middle;
}

.name{
  font-size:80%;
  color:#999;
}
.actions{
  display:inline-block;
  float:right;
  margin:20px;
}

.actions > a{
  display: inline-block;
  font-size: 20px;
  margin: 0 10px;
}

.delete{
  color:red;
}
 /*https://www.youtube.com/watch?v=ejOXdYTp1zM&t=74s*/
</style>
<div class="container">
  <div class="header">
    <h2>My Contacts</h2>
    <!-- <a>Add Contact</a> -->
    @if (session('delete_user'))
                        <div class="alert alert-success">
                             {{ session('delete_user') }} 
                        </div>
@endif

   @if (session('update_user'))
                        <div class="alert alert-success">
                             {{ session('update_user') }} 
                        </div>
@endif

  </div>  
  <div class="sidebar">
    <ul>
      <li><a href="{{'contact-list'}}">Contacts</a></li>
      <!-- <li><a>Sidebar Item</a></li>
      <li><a>Sidebar Item</a></li>
      <li><a>Sidebar Item</a></li>
      <li><a>Sidebar Item</a></li> -->
    </ul> 
  </div>
  <div class="contact-list">
    <ul>
      @foreach($contact_data as $key)
      <li>
        <img  class="avatar " src="http://via.placeholder.com/350x350">
        <p id="details_id{{$key->id}}" style="display:inline-block"><span class="name">{{$key->name}}</span><br>{{$key->usr_mobile}}</p>
        <p>
             <div id="ticket_second_div{{$key->id}}" style="display: none;">  
              <input type="text" id="name{{$key->id}}" name="name" value="" >
              <input type="text" id="usr_mobile{{$key->id}}" name="usr_mobile" value="">
              <i class="fa fa-check" aria-hidden="true" onclick="return savename({{$key->id}})">Save</i>
                                                        
              </div>

        </p>
        <span class="actions">
          <a class="edit" id="edit{{$key->id}}" data-id="{{$key->id}}" data-name="{{$key->name}}" data-mobile="{{$key->usr_mobile}}" onclick="showModal(this)"><i class="fa fa-pencil-square-o"></i></a>
          <a class="edit" id="cross_edit{{$key->id}}" onclick="hide_field({{$key->id}})" style="display:none"><i class="fa fa-times" aria-hidden="true"></i></i></a>        
          <a class="delete" onclick="delete_contact({{$key->id}})"><i class="fa fa-trash"></i></a>
        </span> 
      </li>
      @endforeach
    
    </ul> 
  </div>
  <!-- START MODAL -->

  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Contact</h4>
          <div class="col-lg-12">
      <div class="alert alert-danger print-error-msg" style="display:none">
        <ul> </ul>
    </div>
    </div>
        </div>
           <form id="edit_user">

        <div class="modal-body">
     
          <!-- HIDDEN FIELD -->
    <input type="hidden" class="form-control" id="id" name="id">
  <div class="form-group">
    <label for="name">Name:</label>

    <input type="text" class="form-control" id="name" name="name" required>
    <span class="error-data"></span>
  </div>
  <div class="form-group">
    <label for="usr_mobile">Mobile:</label>
    <input type="text" class="form-control" id="usr_mobile" name="usr_mobile" required>
    <span class="error-data"></span>
  
 

        </div>
        <div class="modal-footer">
           <button type="submit" class="btn btn-default" id="update_data">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
 <!-- END MODAL -->
    
</div>

  <div>



@endsection