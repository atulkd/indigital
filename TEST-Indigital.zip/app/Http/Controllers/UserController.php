<?php

namespace App\Http\Controllers;

use Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Input;
use Log;
use Illuminate\Http\Request;
use Igoshev\Captcha\Facades\Captcha;
use Session;
use App\User;
use App\Notifications\errorNotification;
use DB;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $req)
    {
        //dd($req->usr_name);
        // echo "into create user table";
        $user_fields = Input::only(
            'cmp_usr_name',
            'cmp_usr_mobile',
            'cmp_usr_email',
            'cmp_usr_password',
            'retype_password',
            'cmp_name',
            'cmp_usr_designation',
            'cmp_size',
            'g-recaptcha-response'
            );
        $error_message= array(
            'cmp_usr_name.required' => "Enter User Name.",
            'cmp_usr_mobile.required'=>"Enter User Mobile No.",
            'cmp_usr_mobile.min'=>"Enter valid Mobile No.",
            'cmp_usr_mobile.max'=>"Enter valid Mobile No.",
            'usr_mobile.unique'=>"Mobile has already been used. Please use another Mobile Number.",

            'cmp_usr_email.required' => "Enter User email.",
            'cmp_usr_email.email' => "Enter valid email.",
            'email.unique' =>"Email has already been used. Please use another Email address.",
            
            'cmp_usr_password.required' => "Enter User password.",
            'cmp_usr_password.min' => "Password must be 6 digit long",
            'retype_password.required'=>"Retype password.",
            'retype_password.confirmed' => "Enter the same password again.",
            'cmp_name.required' =>"Enter company name.",
            'cmp_usr_designation.required' => "Enter User Designation.",
            'cmp_size.required' => "Enter Company Size.",
            'g-recaptcha-response.required' => "Enter Captcha."
             );

         $rules = array(
          'cmp_usr_name' => 'required',
          'cmp_usr_mobile' =>'required',
          'usr_mobile' =>'min:10|max:10|unique:users',
          'cmp_usr_email' =>'required',
          'email' =>'email|unique:users',
          
          'cmp_usr_password' => 'required|string|min:6',
          'retype_password' => 'required',
          'cmp_name' => 'required',
          'cmp_usr_designation'=>'required',
          'cmp_size' => 'required',
          'g-recaptcha-response' => 'required'
          );

        $validation_result=Validator:: make($user_fields,$rules,$error_message);
        if($validation_result->fails())
        {
            
            echo json_encode(array('success'=>false,'message'=>$validation_result->errors()->all(),'error_type'=>'user'));
        }
        else
        {
            try
            {
                $user =new User;
              
                $user->name=trim($req->cmp_usr_name);
                $user->email=trim($req->cmp_usr_email);
                $user->usr_mobile=trim($req->cmp_usr_mobile);

                $user->password=bcrypt(trim($req->cmp_usr_password));
                $user->usr_cmp_name=trim($req->cmp_name);
                $user->usr_designation=trim($req->cmp_usr_designation);
                $user->usr_cmp_size=trim($req->cmp_size);
                $user->usr_status=1;
                //$user->usr_created_at=date('Y-m-d H:i:s');
                $user->save();
                $usr_id=$user->id;
                if(!empty($usr_id))
                {
                    $req->session()->flash('create_user', 'Company User Is Added Successfully');
                    echo json_encode(array('success'=>true,'message'=>"Company User Is Added Successfully",'linkn'=>"contact"));
                }
                else
                {
                    echo json_encode(array('success'=>false,'message'=>"Some Error Occurs While Adding Company User"));
                }


            }
            catch(Exception $e)
            {
                echo json_encode(array("success"=>false,"message"=>"Some Error Occured Try Again","error_type"=>'System'));
            }
        }


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }
     public function userList()
     {
        $user_data= DB::table('users')->where('usr_status','1')->orderBy('created_at','dsc')->get();
        return view('contact',compact('user_data'));
     }
     public function userContactList()
     {
        $contact_data= DB::table('users')->where('usr_status','1')->orderBy('created_at','dsc')->get();
        return view('contact-list',compact('contact_data'));
     }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteContact(Request $request)
    {
        try
        {
            // $id = $request->id;
            // $contact_data= DB::table('users')->where('id',$id);
            // $contact_data->delete();
            $user = User::find($request->id);    
            $user->delete();
            $request->session()->flash('delete_user', 'user contact Deleted successfully');
            echo json_encode(array("success"=>true,"message"=>"user contact deleted successfully",'linkn'=>"contact-list"));
        }
        catch(Exception $e)
        {
            echo json_encode(array("success"=>false,"message"=>"Some Error Occured Try Again"));
        }
        
        
    }
    public function updateContact(Request $request)
    {   
        $user_fields = Input::only(
            'name',
            'usr_mobile'
            );

          $error_message= array(
            'name.required' => "Enter User Name.",
            'usr_mobile.required'=>"Enter User Mobile No.",
            'usr_mobile.min'=>"Enter valid Mobile No.",
            'usr_mobile.max'=>"Enter valid Mobile No.",
            'usr_mobile.unique'=>"Mobile has already been used. Please use another Mobile Number.",

             );

           $rules = array(
          'name' => 'required',

          'usr_mobile' =>'required|min:10|max:10|unique:users,usr_mobile,'.$request->id.''
          );
            // unique('users')->ignore($user->id, 'user_id')
        $validation_result=Validator:: make($user_fields,$rules,$error_message);  
        if($validation_result->fails())
        { 
            echo json_encode(array('success'=>false,'message'=>$validation_result->errors()->all(),'error_type'=>'user'));
        }
        else
        {

             try
                {
                    DB::table('users')
                    ->where('id', $request->id)
                    ->update(['name' =>  $request->name,
                            'usr_mobile' => $request->usr_mobile]);
                    $request->session()->flash('update_user', 'user contact Updated successfully');
                    echo json_encode(array("success"=>true,"message"=>"user contact Updated successfully",'linkn'=>"contact-list"));
                }
                catch (Exception $e)
                {
                       echo json_encode(array("success"=>false,"message"=>"Some Error Occured Try Again"));
                }

        }
        
       
        
    }
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

     public function checkUserEmail(Request $req)
    {
        
        $check_user_email=DB::table('users')->where('email',$req->cmp_usr_email);
        if($check_user_email->count() == 0)
        {
            
            return 'true';
        }
        else
        {   
            
            return 'false';
        }
    }

    public function checkUserMobile(Request $req)
    {    
        $id=$req->id;
         
        if($id)
        {
            $check_user_mobile=DB::table('users')->where('usr_mobile',$req->cmp_usr_mobile)->where('id',$req->id);
        }
        else
        {
            $check_user_mobile=DB::table('users')->where('usr_mobile',$req->cmp_usr_mobile);
        }
        
        if($check_user_mobile->count() == 0)
        {
            return 'true';
        }
        else
        {
            return 'false';
        }
    }
}
