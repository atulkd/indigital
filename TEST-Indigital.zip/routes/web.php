<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('contact','UserController@userList');
Route::get('contact-list','UserController@userContactList');
Route::get('/', 'HomeController@index')->name('home');

Route::get('create-new-company-user', function () {
	 return view('company-user-registration');
});

Route::post('check-user-email-availability', 'UserController@checkUserEmail');

Route::post('check-user-mobile-availability', 'UserController@checkUserMobile');
Route::post('insert-company-user', 'UserController@create');

Route::post('delete-contact', 'UserController@deleteContact');
Route::post('update-contact', 'UserController@updateContact');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


