$(function() 
{

$.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var check = false;
        return this.optional(element) || regexp.test(value);
    },);

  $("#company-user-registration-form").validate({
   ignore: 'input[type="hidden"]',
   rules: {
    cmp_usr_name: {
      required: true,


    },
    cmp_usr_email: {
      required: true,
      email:true,
      remote: {
    type: 'post',
    url: 'check-user-email-availability',
   
     data: {
        'cmp_usr_email': function () { return $('#cmp_usr_email').val(); }
    },
   dataType: 'json',
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
    }
    },  
    cmp_usr_mobile: {
      required: true,
      regex: /^[1-9]{1}[0-9]{9}$/,
      remote: {
    type: 'post',
    url: 'check-user-mobile-availability',
   
     data: {
        'cmp_usr_mobile': function () { return $('#cmp_usr_mobile').val(); }
    },
   dataType: 'json',
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
    }

    },  
    cmp_usr_password: {
      required: true,
    },
    retype_password: {
      required: true,
        equalTo: '#cmp_usr_password'
    },
    cmp_name: {
      required: true,
    },
    cmp_usr_designation:{
      required:true,
    },
    cmp_size:{
      required:true,
    },

  },

  messages: {

    cmp_usr_name: {
      required: "Enter User Name.",
    },  
    cmp_usr_email: {
      required: "Enter User email.",
      email: "Enter valid email.",
      remote: "Email has already been used. Please use another Email address.",
    },  
    cmp_usr_mobile: {
      required: "Enter User mobile Number.",
     regex: 'Enter valid Mobile Number.',
      remote: "This Mobile number Has been Already Exist,Please Enter Another Number.",
    },  
    cmp_usr_password: {
      required: "Enter User password.",

    },
    retype_password: {
      required:  "Enter Password.",
      equalTo: "Enter the same password again."


    },
    cmp_name: {
      required:  "Enter company name.",
    },

    cmp_usr_designation: {
      required:  "Enter User Designation.",
    },

    cmp_size: {
      required:  "Enter Company Size.",
    },
    
  },
  errorPlacement: function(error, element){
    error.appendTo( element.next('.error-message') );
  },
  submitHandler: function(form){
    dataString = $('#company-user-registration-form').serialize();
    //console.log(dataString);
    $.ajax({
      type: "POST",
      url: "/insert-company-user",
      data: dataString,
      dataType: 'json',
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
        beforeSend: function(){
         $('#form_submit').html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i> Processing'); 
     $('#form_submit').prop("disabled", true);
      },

   success: function(response)
   {

    if(response.success==true)
    {
      window.location.href=response.linkn;
     
    }
    else{
      $('#form_submit').html('Submit'); 
       $('#form_submit').prop("disabled", false);
      if(response.error_type=='user')
      {
          printErrorMsg(response.message);
      }
      else
      {
        alert(response.message);
        location.reload();
      }
    }
   }

});
  }

});

});
function printErrorMsg (msg) {
  $(".print-error-msg").find("ul").html('');
  $(".print-error-msg").css('display','block');
  $.each( msg, function( key, value ) {
    $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
  });
}

function delete_contact(id)
{
   var x = confirm("Are you sure you want to delete?");
    if (x)
    {
      data={
        id:id
      },
      $.ajax({
      type: "POST",
      url: "delete-contact",
      data: data,
      dataType: 'json',
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
             
   success: function(response)
   {

    if(response.success==true)
    {
      window.location.href=response.linkn;
     
    }
    else{
      alert(response.message);
        location.reload();
    }
   }

});

        
    } 
    else
    {
       return false;
    }
                   
}



$(document).ready(function() {
  $('#cmp_usr_password').keyup(function() {
    $('#result').html(checkStrength($('#cmp_usr_password').val()))
  })
  function checkStrength(password) {
    var strength = 0
    if (password.length < 6) {
      $('#result').removeClass()
      $('#result').addClass('short')
      return 'Too short'
    }
    if (password.length > 7) strength += 1
// If password contains both lower and uppercase characters, increase strength value.
if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) strength += 1
// If it has numbers and characters, increase strength value.
if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) strength += 1
// If it has one special character, increase strength value.
if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
// If it has two special characters, increase strength value.
if (password.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
// Calculated strength value, we can return messages
// If value is less than 2
if (strength < 2) {
  $('#result').removeClass()
  $('#result').addClass('weak')
  return 'Weak'
} else if (strength == 2) {
  $('#result').removeClass()
  $('#result').addClass('good')
  return 'Good'
} else {
  $('#result').removeClass()
  $('#result').addClass('strong')
  return 'Strong'
}
}
});

// function select_field(id,name,usr_mobile)
// {
 

//  $('#edit'+id).css('display','none');
//  $('#cross_edit'+id).css('display','inline-block');
//  $('#details_id'+id).css('display','none');
//  $('#ticket_second_div'+id).css('display','inline-block');
//  $('#name'+id).val(name);
//  $('#usr_mobile'+id).val(usr_mobile);

// }

function showModal(current_tag) {
$('#id').val(current_tag.getAttribute('data-id'));
$('#name').val(current_tag.getAttribute('data-name'));
$('#usr_mobile').val(current_tag.getAttribute('data-mobile'));
$("#myModal").modal();

}

function hide_field(id,name,usr_mobile)
{
 

 $('#edit'+id).css('display','inline-block');
 $('#cross_edit'+id).css('display','none');
 $('#details_id'+id).css('display','inline-block');
 $('#ticket_second_div'+id).css('display','none');
 $('#name'+id).val();
 $('#usr_mobile'+id).val();

}


function savename(id) {

          var name=$('#name'+id).val();
          var usr_mobile=$('#usr_mobile'+id).val();
              data = {
                name:name,
                usr_mobile:usr_mobile,
                 id:id
                }

              $.ajax({
                    type: "POST",
                    url: "update-contact",
                    data: data,
                    dataType: 'json',
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    cache: false,
                    success: function(response){
                        if(response.success==true){
                          alert(response.message);
                                location.reload();
                             
                        }else{
                          alert(response.message);
                          location.reload();
                               

                              }
          
        }
    });

        
}









$(function() 
{
  $("#edit_user").validate({
   ignore: 'input[type="hidden"]',
   rules: {
    name: {
      required: true,

    },
      
    usr_mobile: {
      required: true,
      regex: /^[1-9]{1}[0-9]{9}$/,
    }

  },

  messages: {

    name: {
      required: "Enter User Name.",
    }, 
    usr_mobile: {
      required: "Enter User mobile Number.",
     regex: 'Enter valid Mobile Number.',
    
    }, 
    
  },
  errorPlacement: function(error, element){
    error.appendTo( element.next('.error-data') );
  },
  submitHandler: function(form){
    dataString = $('#edit_user').serialize();
    //console.log(dataString);
    $.ajax({
      type: "POST",
      url: "update-contact",
      data: dataString,
      dataType: 'json',
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      cache: false,
        beforeSend: function(){
         $('#update_data').html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:18px"></i> Processing'); 
     $('#update_data').prop("disabled", true);
      },

   success: function(response)
   {

    if(response.success==true)
    {
      window.location.href=response.linkn;
     
    }
    else{
      $('#update_data').html('Submit'); 
       $('#update_data').prop("disabled", false);
      if(response.error_type=='user')
      {
          printErrorMsg(response.message);
      }
      else
      {
        alert(response.message);
        location.reload();
      }
    }
   }

});
  }

});

});



